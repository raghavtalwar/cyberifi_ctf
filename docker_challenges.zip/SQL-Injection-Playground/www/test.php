<?php
$test_connect = mysqli_connect('localhost', 'root', 'toor');
if (!$test_connect) {
die('Could not connect: ' . mysql_error());
}
echo 'Successful database connection.';
mysql_close($test_connect);
?>
