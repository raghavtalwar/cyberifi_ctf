<?php
$conn = mysqli_connect('db', 'user', 'UserPassword', "main_db");

?>